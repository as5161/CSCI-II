package fractal;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.PixelWriter;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * Fractal program for rendering the Mandelbrot Set.
 *
 * @author RIT CS
 * @author Aamir Sohail
 */
public class Fractal extends Application {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 800;

    /**
     * Generate the Mandelbrot set and return the canvas.
     * @return Canvas containing the Mandelbrot set
     */
    private Canvas makeCanvas() {
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        PixelWriter writer = gc.getPixelWriter();
        long start = System.currentTimeMillis();
        int maxIteration = 1000;
        for (int px = 0; px < WIDTH; px++) {
            for (int py = 0; py < HEIGHT; py++) {
                double Zx = 0.0;
                double Zy = 0.0;
                double Cx = (px - WIDTH / 2.0) * 4.0 / WIDTH;
                double Cy = (py - HEIGHT / 2.0) * 4.0 / HEIGHT;
                int iteration = 0;
                while (Zx * Zx + Zy * Zy < 4 && iteration < maxIteration) {
                    double temp = Zx * Zx - Zy * Zy + Cx;
                    Zy = 2.0 * Zx * Zy + Cy;
                    Zx = temp;
                    iteration++;
                }
                Color color = iteration < maxIteration ? Color.WHITE : Color.BLACK;
                writer.setColor(px, py, color);
            }
        }
        long end = System.currentTimeMillis();
        System.out.println("Render time: " + (end - start) + " ms");
        return canvas;
    }

    /**
     * Launch the GUI.
     * @param stage the JavaFX stage
     */
    @Override
    public void start(Stage stage) throws Exception {
        Scene scene = new Scene(new Group(makeCanvas()));
        stage.setScene(scene);
        stage.setTitle("Fractal - Mandelbrot Set");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
