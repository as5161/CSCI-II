import java.util.*;

/**
 * Graph class that implements IGraph interface.
 * Uses a HashMap to store nodes.
 * @author RIT CS
 */
public class Graph<D> implements IGraph<D> {
    private final Map<D, Node<D>> nodes;

    public Graph() {
        this.nodes = new HashMap<>();
    }

    @Override
    public Collection<Node<D>> getNodes() {
        return nodes.values();
    }


    @Override
    public boolean hasNode(D nodeData) {
        return nodes.containsKey(nodeData);
    }

    @Override
    public Node<D> getNode(D nodeData) {
        return nodes.get(nodeData);
    }

    @Override
    public void addEdge(D from, D to) {
        Node<D> fromNode = nodes.computeIfAbsent(from, Node::new);
        Node<D> toNode = nodes.computeIfAbsent(to, Node::new);
        fromNode.addNeighbor(toNode);
    }

    @Override
    public Node<D> addNode(D data) {
        return nodes.computeIfAbsent(data, Node::new);
    }
}

