import java.util.HashSet;
import java.util.Set;

/**
 * Class representing a node in a graph.
 * The node contains data of the given generic type. Neighbors are
 * stored internally in a collection.
 *
 * @author RIT CS
 * @author <<YOUR NAME HERE>>
 */
public class Node<D> {
    private final D data;
    private final Set<Node<D>> neighbors;

    /**
     * Constructor for Node
     * @param data the value of the node
     */
    public Node(D data) {
        this.data = data;
        this.neighbors = new HashSet<>();
    }

    /**
     * Get the data stored in the node.
     * @return data of the node
     */
    public D getData() {
        return data;
    }

    /**
     * Add a neighbor to this node.
     * @param neighbor the node to be added as a neighbor
     */
    public void addNeighbor(Node<D> neighbor) {
        neighbors.add(neighbor);
    }

    /**
     * Get the neighbors of this node.
     * @return set of neighbors
     */
    public Set<Node<D>> getNeighbors() {
        return neighbors;
    }

    @Override
    public String toString() {
        return data.toString();
    }
}
