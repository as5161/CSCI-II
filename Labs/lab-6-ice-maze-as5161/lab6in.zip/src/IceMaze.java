import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class IceMaze {
    private final Graph<Coord> graph;
    private final char[][] grid;
    private final int height;
    private final int width;
    private final int exitRow;
    private final Coord exitCoord;

    public IceMaze(char[][] grid, int height, int width, int exitRow) {
        this.grid = grid;
        this.height = height;
        this.width = width;
        this.exitRow = exitRow;
        this.exitCoord = new Coord(exitRow, width - 1);
        this.graph = new Graph<>();
        buildGraph();
    }

    public static IceMaze readFile(String filename) throws InvalidMazeException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String metaLine = reader.readLine();
            if (metaLine == null) throw new InvalidMazeException("Empty file");
            String[] metaParts = metaLine.trim().split("\\s+");
            if (metaParts.length != 3) throw new InvalidMazeException("Invalid first line");

            int height = Integer.parseInt(metaParts[0]);
            int width = Integer.parseInt(metaParts[1]);
            int exitRow = Integer.parseInt(metaParts[2]);
            if (exitRow < 0 || exitRow >= height) throw new InvalidMazeException("Invalid exit row: " + exitRow);

            char[][] grid = new char[height][width];
            for (int r = 0; r < height; r++) {
                String line = reader.readLine();
                if (line == null) throw new InvalidMazeException("Missing grid row " + r);
                String[] cells = line.trim().split("\\s+");
                if (cells.length != width) throw new InvalidMazeException("Invalid row " + r + " length");

                for (int c = 0; c < width; c++) {
                    char cell = cells[c].charAt(0);
                    if (cell != '.' && cell != '*') throw new InvalidMazeException("Invalid cell: " + cell);
                    grid[r][c] = cell;
                }
            }

            return new IceMaze(grid, height, width, exitRow);

        } catch (IOException e) {
            throw new InvalidMazeException("Error reading file: " + e.getMessage());
        }
    }

    private void buildGraph() {
        Coord exitCoord = new Coord(exitRow, width - 1);
        graph.addNode(exitCoord);

        for (int r = 0; r < height; r++) {
            for (int c = 0; c < width; c++) {
                if (grid[r][c] != '.') continue;

                Coord current = new Coord(r, c);
                graph.addNode(current);

                for (int[] dir : new int[][]{{-1, 0}, {1, 0}, {0, -1}, {0, 1}}) {
                    int newR = r, newC = c;
                    boolean exitFound = false;

                    while (true) {
                        int nextR = newR + dir[0];
                        int nextC = newC + dir[1];

                        if (nextR < 0 || nextR >= height || nextC < 0 || nextC >= width || grid[nextR][nextC] == '*') {
                            break;
                        }

                        if (dir[1] == 1 && newR == exitRow && nextC == width) {
                            exitFound = true;
                            break;
                        }

                        newR = nextR;
                        newC = nextC;
                    }

                    Coord destination = exitFound ? exitCoord : new Coord(newR, newC);
                    if (!destination.equals(current)) {
                        graph.addEdge(current, destination);
                    }
                }
            }
        }
    }

    public void findEscapes() {
        Map<Coord, Set<Coord>> escapes = new HashMap<>();

        for (Node<Coord> startNode : graph.getNodes()) {
            Coord startCoord = startNode.getData();
            Set<Coord> neighbors = new TreeSet<>(Comparator.comparingInt(Coord::r).thenComparingInt(Coord::c));

            for (Node<Coord> neighbor : startNode.getNeighbors()) {
                Coord neighborCoord = neighbor.getData();
                neighbors.add(neighborCoord);
            }

            escapes.put(startCoord, neighbors);
        }

        List<Coord> sortedCoords = new ArrayList<>(escapes.keySet());
        sortedCoords.sort(Comparator.comparingInt(Coord::r).thenComparingInt(Coord::c));

        for (Coord coord : sortedCoords) {
            Set<Coord> neighbors = escapes.get(coord);
            System.out.print("(" + coord.r() + "," + coord.c() + "):  ");

            if (neighbors.isEmpty()) {
                System.out.println();
            } else {
                List<Coord> sortedNeighbors = new ArrayList<>(neighbors);
                sortedNeighbors.sort(Comparator.comparingInt(Coord::r).thenComparingInt(Coord::c));
                StringJoiner joiner = new StringJoiner(", ");
                for (Coord neighbor : sortedNeighbors) {
                    joiner.add("(" + neighbor.r() + "," + neighbor.c() + ")");
                }
                System.out.println(joiner.toString());
            }
        }
    }

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java IceMaze <filename>");
            return;
        }

        try {
            IceMaze maze = IceMaze.readFile(args[0]);
            maze.findEscapes();
        } catch (InvalidMazeException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
