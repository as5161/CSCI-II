/**
 * Exception thrown for an invalid maze file.
 */
public class InvalidMazeException extends Exception {
    public InvalidMazeException(String message) {
        super(message);
    }
}
