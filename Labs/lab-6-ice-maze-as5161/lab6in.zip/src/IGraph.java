import java.util.Collection;

/**
 * Interface for a directed graph.
 * @param <DataType> Type of data contained in the nodes of the graph
 */
public interface IGraph<DataType> {
    Collection<Node<DataType>> getNodes();
    boolean hasNode(DataType nodeData);
    Node<DataType> getNode(DataType nodeData);
    void addEdge(DataType from, DataType to);
    Node<DataType> addNode(DataType data);
}
